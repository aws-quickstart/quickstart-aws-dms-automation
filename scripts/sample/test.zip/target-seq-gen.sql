 create sequence dms_sample.player_seq increment by 10 minvalue 1 start with 51561;

 create sequence dms_sample.sporting_event_seq increment by 10 minvalue 1 start with 11411;

 create sequence dms_sample.sporting_event_ticket_seq increment by 10 minvalue 1 start with 565301531;

 create sequence dms_sample.sport_location_seq increment by 1 minvalue 1 start with 63;

 create sequence dms_sample.sport_team_seq increment by 10 minvalue 1 start with 611;

